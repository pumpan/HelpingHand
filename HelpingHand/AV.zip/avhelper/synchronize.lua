prefix_Channel = "AVHelper";
prefix_Channel_password = "pass123";
prefix_talking_code = "A1";


sync_data = {
["Drek"] = 100,
["Van"] = 100,
["all"] = 0,
["update"] = 0
};

sync_data_Guards = {};

sync_id = 0;
anti_spam_sync_time = 0;
anti_spam_sync_time_delay = 3;
sync_message_confirm = false;

function broadcast_message(value, sync_type, confirm)
	confirm = confirm or false;
	
	got_sent = false;
	if is_connected() and Sync_enable and Sync_anti_spam() and (Sync_bypass_mode or IsinAVBattleground()) then
		--console(sync_type);
		if check_if_sync_exists(sync_type) then
		
			if Sync_bypass_mode then
				Bgid = 0;
			else
				Bgid = Get_Battleground_Instance_ID();
			end
			
			dex = GetChannelName(prefix_Channel)
			
			if sync_message_confirm == false then
				sync_id = sync_id + 1;
			else
				sync_id = sync_id;
				console(Sync_console_name .. " Failed to confirm last message", "red", getglobal("Sync_console_show"));
			end
			
			base64_msg = Base64_Encode("AV" .. Bgid .. "-" .. sync_type .. "-" .. value .. "-" .. sync_id .. "-" .. prefix_talking_code)
			
			if StringLength_Check(base64_msg) == false then
				console(Sync_console_name .. " Failed to send message as its too long", "red", getglobal("Sync_console_show"));
				return false;
			end
			
			SendChatMessage(base64_msg, "CHANNEL", nil, dex);
			sync_data[sync_type] = value;
			console(Sync_console_name .. " Boardcasting synctype " .. sync_type .. " with value of ".. value, "white", getglobal("Sync_console_show"));
			sync_message_confirm = true;
			got_sent = true;
		else
			console(Sync_console_name .. " Error on sync: " .. sync_type, "red", getglobal("Sync_console_show"));
		end
		
		if got_sent == false then
			console(Sync_console_name .. " Failed to send message", "red", getglobal("Sync_console_show"))
		end
	end
end

function get_sync_data(sync_type)
	if check_if_sync_exists(sync_type) then
		return sync_data[sync_type];
	else
		console(Sync_console_name .. " Error getting sync for " .. sync_type, "red", getglobal("Sync_console_show"));
	end
end

function StringLength_Check(text)
	if string.len(text) > 200 then
		return false;
	else
		return true;
	end
end

function Sync_anti_spam() -- no longer panic spam, note delay arg must always be passed
	if anti_spam_sync_time > GetTime() then -- check time
		return false;
	else
		anti_spam_sync_time = GetTime() + (anti_spam_sync_time_delay); -- set seconds
		return true;
	end
end

function check_if_sync_exists(sync_type)
	found = false
		for k, v in pairs(sync_data) do
			if k == sync_type then
				found = true
			end
		end
	return found
end

function split(s, sep)
    local fields = {}
	local count = 1;
	
    local sep = sep or " "
    local pattern = string.format("([^%s]+)", sep)
    string.gsub(s, pattern, function(c) 
	
	fields[count] = c 
	count = count + 1
	end)

    return fields
end

function sync_connect()
	if Sync_enable then
		if is_connected() then
			return true;
		else
			if Sync_hide_channel then
				JoinChannelByName(prefix_Channel, nil, CHATAVTEST:GetID(), nil)
			else
				JoinChannelByName(prefix_Channel, nil, nil, nil)
			end	
			console(Sync_console_name .. " Connected", "blue", getglobal("Sync_console_show"));
			
			broadcast_message("request", "update");
		end
	end
end

function sync_disconnect()
	if Sync_enable then
		if is_connected() then
			LeaveChannelByName(prefix_Channel);
			console(Sync_console_name .. " Disconnected", "red", getglobal("Sync_console_show"));
		end
		return true;
	end
end

function is_connected()
	if GetChannelName(prefix_Channel) ~= 0 then
		return true;
	else
		return false;
	end
end

local frame_broadcaster = CreateFrame("FRAME");
frame_broadcaster:RegisterEvent("CHAT_MSG_CHANNEL");
local function eventHandler_broadcaster(self, event, ...)
	if Sync_enable then
		channel = arg9
		if channel == prefix_Channel then
			retOK, ret1 = pcall(Base64_Decode, arg1);
			if retOK then
				user = arg2;
				name, realm = UnitName("player");
				
				if user == name then
					if sync_message_confirm == true then
						sync_message_confirm = false; -- The message was broadcasted
						console(Sync_console_name .. " Confirmed transaction sync ID:" .. sync_id, "white", getglobal("Sync_console_show"));
					else
						sync_message_confirm = false;
						console(Sync_console_name .. " Could not confirm is message was sent, deleted transaction sync ID:'" .. sync_id, "red", getglobal("Sync_console_show"));
						sync_id = sync_id - 1;
					end
				end
				
				if user ~= name then
					msg = ret1;			
					if channel == prefix_Channel and (Sync_bypass_mode or (IsinAVBattleground() and IsInBattleground())) then
						
						if Sync_bypass_mode then
							Bgid = 0;
						else
							Bgid = Get_Battleground_Instance_ID();
						end
						
						recvdata = split(msg, "-");
						
						avid = tostring(recvdata[1])
						sync_type = tostring(recvdata[2])
						value = tostring(recvdata[3])
						Recv_Sync_id = tonumber(recvdata[4])
						talk_code = tostring(recvdata[5])
												
						if talk_code ~= prefix_talking_code then
							console(Sync_console_name .. " Error Addon may be out of date, Removed peer connection", "red", getglobal("Sync_console_show"));
							return false;
						end
										
						if sync_id == 0 then
							sync_id = Recv_Sync_id; -- accept sync code
							console(Sync_console_name .. " Syncing with ID " .. sync_id, "green", getglobal("Sync_console_show"));
						elseif (sync_id+1) == Recv_Sync_id then
							sync_id = Recv_Sync_id;
							console(Sync_console_name .. " Updated Sync ID " .. sync_id, "green", getglobal("Sync_console_show"));
						else
							if sync_message_confirm == true or Recv_Sync_id > sync_id then
								sync_message_confirm = false;
								sync_id = Recv_Sync_id;
								console(Sync_console_name .. " We're out of sync. Updated to latest code." .. sync_id, "green", getglobal("Sync_console_show"));
							elseif sync_type ~= "update" then
								broadcast_message(Get_my_BG_data(), "all");
								console(Sync_console_name .. " Bad Sync ID, refused transaction from " .. user .. ". " .. sync_id .. "/" .. Recv_Sync_id, "red", getglobal("Sync_console_show"))
								return false; -- getting bad sync data. possible hacker todo: work on this more
							end
						end
								
						console(Sync_console_name .. " Received datatype '" .. sync_type .. "' and is set to '" .. value .. "'", "orange", getglobal("Sync_console_show"));
						if sync_type == "all" then
							Set_my_BG_data(value);
							--return;
						elseif sync_type == "update" and value == "request" then
							broadcast_message(Get_my_BG_data(), "all");
						end

						if ("AV"..Bgid) == avid then
							if check_if_sync_exists(sync_type) then
								sync_data[sync_type] = value;
							else
								console(Sync_console_name .. " Error on sync: " .. sync_type, "red", getglobal("Sync_console_show"));
							end
						end
					end
				end
			end
		end
	end
end
--frame_broadcaster:Hide();
frame_broadcaster:SetScript("OnEvent", eventHandler_broadcaster);

if getglobal("Sync_console_show") == "true" then
	SLASH_BROCAST_SLASHCMD1 = '/castHP'
	SlashCmdList['BROCAST_SLASHCMD'] = function(msg)
		broadcast_message(msg, "Drek")
	end

	SLASH_BROCAST2_SLASHCMD1 = '/cast2'
	SlashCmdList['BROCAST2_SLASHCMD'] = function(msg)
		console("MSG: " ..  get_sync_data("Drek"));
	end

	SLASH_BROCAST3_SLASHCMD1 = '/castAll'
	SlashCmdList['BROCAST3_SLASHCMD'] = function(msg)
		sync_data['ALL'] = "";
		
		for k,v in pairs(sync_data) do
			
		end
	end
	
	
	SLASH_BROCAST3_SLASHCMD1 = '/ForceUpdate'
	SlashCmdList['BROCAST3_SLASHCMD'] = function(msg)
		broadcast_message("request", "update")
	end

	SLASH_BROCAST_DATA_SLASHCMD1 = '/syncTest'
	SlashCmdList['BROCAST_DATA_SLASHCMD'] = function(msg)
		console("---------------", "red");
		for k,v in pairs(sync_data) do
			console("DataType: " .. k .. " has value " .. v, "green");
		end
		console("Sync ID: " .. sync_id, "blue");
		console("---------------", "red");
	end

	SLASH_BROCASTMODE_SLASHCMD1 = '/sync'
	SlashCmdList['BROCASTMODE_SLASHCMD'] = function(msg)
		if msg == "on" then
			sync_connect();
		else
			sync_disconnect();
		end
	end
end
