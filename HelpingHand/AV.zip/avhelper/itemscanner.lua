itemnames = {};

function Item_ScanInspect(unit)
	itemnames = {};

	local i, j, slotName,sunit,ifScanSet;
	local itemName, tmpText, tmpStr, tmpSet, val, lines, set;

	sunit="target";
	ifScanSet=0;

	for i=1, 19 ,1 do
		
		local link = nil;
		link = GetInventoryItemLink(sunit, i);

		if (link~=nil) then

			local item = gsub(link, ".*(item:%d+:%d+:%d+:%d+).*", "%1", 1);
			
			SCObjectTooltip:Hide()
			SCObjectTooltip:SetOwner(UIParent, "ANCHOR_NONE");

			SCObjectTooltip:SetHyperlink(item);			
			itemName = SCObjectTooltipTextLeft1:GetText();
			lines = SCObjectTooltip:NumLines();

			for j=2, lines, 1 do
				tmpText = getglobal("SCObjectTooltipTextLeft"..j);
				val = nil;
				if (tmpText:GetText()) then
					tmpStr = tmpText:GetText();
				end
			end
			table.insert(itemnames, itemName)
		end
	end
	
	SCObjectTooltip:Hide()
end