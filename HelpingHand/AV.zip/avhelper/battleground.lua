-- Battleground Data

drek_state = 0; -- count messages as states
drek_pull_time = 0; --measure whole pull time
drek_pull_check_time = 0; --short time check, if message too quick we know they failed
drek_pull_time_compare = 0; -- compare time between states to predict new state

van_state = 0;
van_pull_time = 0;
van_pull_check_time = 0;
van_pull_time_compare = 0;


BG_ASSETS = {
	-- Key = name V = state,
	["Stormpike_Aid_Station"] = {0}, 
	["Dun_Baldar_South_Bunker"] = {0}, 
	["Dun_Baldar_North_Bunker"] = {0}, 
	["Icewing_Bunker"] = {0}, 
	["Stonehearth_Bunker"] = {0}, 
	["Frostwolf_Relief_Hut"] = {0}, 
	["West_Frostwolf_Tower"] = {2}, 
	["East_Frostwolf_Tower"] = {2},
	["Tower_Point"] = {2}, 
	["Iceblood_Tower"] = {2},
	["Van"] = {0},
	["Drek"] = {0}
}


Warmasters = {
	-- Name, State = 1 alive, 0= dead
	[1] = {"Dun Baldar South Warmaster", 0}, 
	[2] = {"Icewing Warmaster", 0}, 
	[3] = {"Stonehearth Warmaster", 0},
	[4] = {"Dun Balder North Warmaster", 0}, 
	[5] = {"Tower Point Warmaster", 1},
	[6] = {"Iceblood Warmaster", 1},
	[7] = {"East Frostwolf Warmaster", 1}, 
	[8] = {"West Frostwolf Warmaster", 1}
}

Marshals = {
	-- Name, State = 1 alive, 0= dead
	[1] = {"Dun Baldar South Marshal", 1}, 
	[2] = {"Icewing Marshal", 1}, 
	[3] = {"Stonehearth Marshal", 1},
	[4] = {"Dun Baldar North Marshal", 1},
	[5] = {"Tower Point Marshal", 0}, 
	[6] = {"Iceblood Marshal", 0}, 
	[7] = {"East Frostwolf Marshal", 0}, 
	[8] = {"West Frostwolf Marshal", 0}
}

BG_Yell_TEMPLATE = {
	-- 	    NAME, TEXT 2 Search                  
	-- van
	{"Van", "your General is under attack"}, 
	{"Van", "never get me out of me bunker"}, -- ended
	{"Van", "try again without yer cheap"}, 
	{"Van", "Your attacks are weak"}, 
	{"Van", "best you can do"}, 
	{"Van", "the Alliance, will"}, 
	{"Van", "more than you rabble to bring me"}, 
	{"Van", "will not be swayed from our"}, 
	{"Van", "clan bows to no one"}, 

	-- drek
	{"Drek", "Slay them all!"}, 
	{"Drek", "Frostwolf legion out"},
	{"Drek", "Your attacks are slowed by the cold"}, 
	{"Drek", "no match for the strength of"},
	{"Drek", "you will meet your ancestors"}, 
	{"Drek", "weak, and your blows are"},
	{"Drek", "will not leave Alterac Valley on your"},
	{"Drek", "cannot defeat the Frostwolf"}

}


Assets_texture_states = {
[1] = "Interface\\Addons\\avhelper\\textures\\bunker_alliance",
[2] = "Interface\\Addons\\avhelper\\textures\\bunker_horde",
[3] = "Interface\\Addons\\avhelper\\textures\\bunker_horde_contested_horde",
[4] = "Interface\\Addons\\avhelper\\textures\\bunker_horde_contested_alliance",
[5] = "Interface\\Addons\\avhelper\\textures\\tower_down"
}

gy_texture_states = {
[1] = "Interface\\Addons\\avhelper\\textures\\Alliance_GY",
[2] = "Interface\\Addons\\avhelper\\textures\\Horde_GY",
[3] = "Interface\\Addons\\avhelper\\textures\\Horde_GY_contested",
[4] = "Interface\\Addons\\avhelper\\textures\\Alliance_GY_contested"
}

function Get_my_BG_data()
	count = 0;
	data = "{";
	for k, v in pairs(BG_ASSETS) do 
		count = count+1;
		if v[1] > 0 then
			data = data .. tonumber(count) .. "," .. tonumber(v[1]) .. "|";
		end
	end
	
	count = 0;
	data = data .. "}{";
	for k, v in pairs(Warmasters) do 
		count = count+1;
		if tonumber(Warmasters[k][2]) > 0 then
			data = data .. tonumber(count) .. "," .. tonumber(v[2]) .. "|";
		end
	end
	data = data .. "}{";
	count = 0;
	for k, v in pairs(Marshals) do 
		count = count+1;
		if tonumber(v[2]) > 0 then
			data = data .. tonumber(count) .. "," .. tonumber(v[2]) .. "|";
		end
	end
	data = data .. "}"
	return data;
end

function Set_my_BG_data(data)
	assets = split(data, "{(.*)}")
	item = split(assets[1], "|")
	for k, v in pairs(item) do 
		value = split(v, ",")
		count = 0;
		for k, v in pairs(BG_ASSETS) do 
			count = count+1;
			if count == tonumber(value[1]) then
				if v[1] ~= tonumber(value[2]) then
					v[1] = tonumber(value[2]);
					console("Recived update for " .. k .. " has been updated.", "white", getglobal("BG_console_show"))
				end
			end
		end
	end
	
	item = split(assets[2], "|")
	for k, v in pairs(item) do 
		value = split(v, ",")
		if tonumber(value[2]) > 0 then
			Warmasters[tonumber(value[1])][2] = tonumber(value[2]);
		else
			Warmasters[tonumber(value[1])][2] = 0;
		end
	end
	
	item = split(assets[3], "|")
	for k, v in pairs(item) do 
		value = split(v, ",")
		
		if tonumber(value[2]) > 0 then
			Marshals[tonumber(value[1])][2] = tonumber(value[2]);
		else
			Marshals[tonumber(value[1])][2] = 0;
		end
	end
	
	update_ui();
end

function state_to_text(state)
	if state == 0 then
	elseif state == 1 then
		return "Alliance";
	elseif state == 2 then
		return "Horde";
	elseif state == 3 then
		return "Contested Horde";
	elseif state == 4 then
		return "Contested Alliance";
	elseif state == 5 then
		return "Tower Down";
	else
		return "Error";
	end
end


local frameBG_Yells = CreateFrame("FRAME"); -- process monster yells
frameBG_Yells:RegisterEvent("CHAT_MSG_MONSTER_YELL");
function eventHandler_BGYells(event, ...)

	function get_side(arg1)
		s, f, side = string.find(arg1, "by the (.*)!");
		if side == nil then
			s, f, side = string.find(arg1, "the (.*) will destroy it!");
		end
		
		if side == nil then
			s, f, side = string.find(arg1, "the (.*) will capture it!");
		end
		
		if side == nil then
			s, f, side = string.find(arg1, "was taken by the (.*)!");
		end
		
		if side ~= nil then
			console(BG_console_name .. " Found side from message value: " .. side, "white", getglobal("BG_console_show"))
		end
		
		return side
	end
	
	function data_extract(src,get)
		if strfind(arg1, get) then
			s, f, Data = string.find(arg1, get);
			return string.gsub(Data, " ", "_")
		else
			return false
		end
	end
	
	function check_if_registered(key)
		found = false
		for k, v in pairs(BG_ASSETS) do 
			if k == key then
				found = true
			end
		end
		return found
	end
	
	function asset_update(k, kv, v)
		BG_ASSETS[k][kv] = v
		console(BG_console_name .. " Updating " .. k .. " to " .. state_to_text(v)..":"..v, "white", getglobal("BG_console_show"))
	end
	
	if IsInBattleground() and IsinAVBattleground() then
	
		side = get_side(arg1);
		
		f1 = data_extract(arg1, "The (.*) is under attack");		
		if(check_if_registered(f1)) then
			if side == "Horde" then
				asset_update(f1, 1, 3);
			else
				asset_update(f1, 1, 4);
			end
		end

		f1 = data_extract(arg1, "(.*) was destroyed by");
		if(check_if_registered(f1)) then
			asset_update(f1, 1, 5);
		end

		f1 = data_extract(arg1, "The (.*) was taken by");
		if(check_if_registered(f1)) then
			if side == "Horde" then
				if f1 == "Stormpike_Aid_Station" and get_player_faction() == "Horde" then
					say("GY UP", 3)
				end
				asset_update(f1, 1, 2);
			else
				if f1 == "Frostwolf_Relief_Hut" and get_player_faction() == "Alliance" then
					say("GY UP ", 3)
				end
				asset_update(f1, 1, 1);
			end
		end
		

		if ((GetBattlefieldInstanceRunTime() / 1000) / 60) >= 6 then
			for k, v in pairs(BG_Yell_TEMPLATE) do 
				if (strfind( arg1, v[2])) then
					BG_ASSETS[v[1]][1] = 2; -- mark them as red
					if v[1] == "Van" then	
						if van_pull_check_time ~= 0 and (GetTime()-van_pull_check_time) < 10 then -- check if too quick
							van_pull_check_time = 0;
							van_state = 0;
							van_pull_time = 0;
							BG_ASSETS[v[1]][1] = 1;
							return
						else
							van_pull_check_time = GetTime()
						end
						
						if van_state > 0 then
							van_pull_time_compare = GetTime()
						end
						
						van_state = van_state + 1;
						
						if van_pull_time_compare > 0 then
							van_pull_time = GetTime() + (GetTime() - van_pull_time_compare)
						else
							van_pull_time = GetTime() + 30;
						end

						if van_state > 2 and get_player_faction == "Horde" then
							PlaySound("Deathbind Sound");
						end
						
					elseif v[1] == "Drek" then
						if drek_pull_check_time ~= 0 and (GetTime()-drek_pull_check_time) < 10 then -- check if too quick
							drek_pull_check_time = 0;
							drek_state = 0;
							drek_pull_time = 0;
							BG_ASSETS[v[1]][1] = 1;
							return
						else
							drek_pull_check_time = GetTime()
						end
						
						if drek_state > 0 then
							drek_pull_time_compare = GetTime()
						end
						
						drek_state = drek_state + 1;
						
						if drek_pull_time_compare > 0 then
							drek_pull_time = GetTime() + (GetTime() - van_pull_time_compare) -- measure time between pulls
						else
							drek_pull_time = GetTime() + 30;
						end
						
						if van_state > 2 and get_player_faction == "Alliance" then
							PlaySound("Deathbind Sound");
						end

					end			
				end
			end
		end
		update_ui();
	end
end
frameBG_Yells:SetScript("OnEvent", eventHandler_BGYells);

local frameBG_Target = CreateFrame("FRAME"); -- target change
frameBG_Target:RegisterEvent("PLAYER_TARGET_CHANGED");
function eventHandler_BGTarget(event, ...)
	if UnitExists("target") and UnitIsEnemy("target", "player") and UnitHealth("target") > 0 then
		if get_player_faction == "Horde" then
			found = false;
			for k, v in pairs(Warmasters) do 
				if UnitName("target") == v[1] then
					found = true;
					break;
				end
			end

			console("Found Enemy alive an well : " .. UnitName("target"));
		end
	end
end
frameBG_Target:SetScript("OnEvent", eventHandler_BGTarget);

function update_ui()	-- UI Data
	
	function Van_update(state)
		if state == 1 or state == 0 then
			van1:Show(); --no incombat
			van2:Hide();
			van_pull_time = 0;
		elseif state == 2 then
			van1:Hide();
			van2:Show(); --incombat
		end
	end
	
	function Drek_update(state)
		if state == 1 or state == 0 then
			drek1:Show(); --no incombat
			drek2:Hide();
			drek_pull_time = 0;
		elseif state == 2 then
			drek1:Hide(); --incombat
			drek2:Show();
		end
	end
	
	function Drek_combat_update(state)
		if state == 0 then
			drekhealth:SetText("100%");
		elseif state == 2 then
			drekhealth:SetText("80%");
		elseif state == 3 then
			drekhealth:SetText("60%");
		elseif state == 4 then
			drekhealth:SetText("40%");
		elseif state == 5 then
			drekhealth:SetText("20%");
		end
	end
	
	function Van_combat_update(state)
		if state == 0 then
			vanhealth:SetText("100%");
		elseif state == 2 then
			vanhealth:SetText("80%");
		elseif state == 3 then
			vanhealth:SetText("60%");
		elseif state == 4 then
			vanhealth:SetText("40%");
		elseif state == 5 then
			vanhealth:SetText("20%");
		end
	end
	
	function guard_death_state(index, asset)
		if get_player_faction() == "Horde" then
			if IsOurAsset(asset) then
				Warmasters[index][2] = 0;
				Marshals[index][2] = 1;
			else
				Warmasters[index][2] = 1;
				Marshals[index][2] = 0;
			end
			console(BG_console_name .. " Guard " .. Marshals[index][1] .. " despawned and " .. Warmasters[index][1] .. " spawned.", "white", getglobal("BG_console_show"))
		else
			if IsOurAsset(asset) then
				Warmasters[index][2] = 1;
				Marshals[index][2] = 0;
			else
				Warmasters[index][2] = 0;
				Marshals[index][2] = 1;
			end
			console(BG_console_name .. " Guard " .. Warmasters[index][1] .. " spawned and " .. Marshals[index][1] .. " despawned.", "white", getglobal("BG_console_show"))
		end
	end	
	
	function IsOurAsset(asset)
	
		Alliance_ASSETS = {"Stormpike_Aid_Station", "Dun_Baldar_South_Bunker", "Dun_Baldar_North_Bunker", "Icewing_Bunker", "Stonehearth_Bunker"};
		Horde_ASSETS = {"Frostwolf_Relief_Hut", "West_Frostwolf_Tower", "East_Frostwolf_Tower", "Tower_Point", "Iceblood_Tower"};
				
		found = false;
		
		if get_player_faction() == "Alliance" then
			for k, v in pairs(Alliance_ASSETS) do 
				if v == asset then
					found = true;
					break;
				end
			end
		end
		
		if get_player_faction() == "Horde" then
			for k, v in pairs(Horde_ASSETS) do 
				if v == asset then
					found = true;
					break;
				end
			end
		end

		return found;
	end
	
	for k, v in pairs(BG_ASSETS) do
	
		if v[1] > 0 then
			
			if k == "Dun_Baldar_South_Bunker" then
				South_Bunker_Placeholder:SetTexture(Assets_texture_states[v[1]]);
				if v[1] == 5 then
					guard_death_state(1, k);
				end
			end
			
			if k == "Icewing_Bunker" then
				Icewing_Bunker_Placeholder:SetTexture(Assets_texture_states[v[1]]);
				if v[1] == 5 then
					guard_death_state(2, k);
				end
			end
			
			if k == "Stonehearth_Bunker" then
				Stonehearth_Bunker_Placeholder:SetTexture(Assets_texture_states[v[1]]);
				if v[1] == 5 then
					guard_death_state(3, k);
				end
			end
			
			if k == "Dun_Baldar_North_Bunker" then
				North_Bunker_Placeholder:SetTexture(Assets_texture_states[v[1]]);
				if v[1] == 5 then
					guard_death_state(4, k);
				end
			end
			
			if k == "Tower_Point" then
				Tower_Point_Placeholder:SetTexture(Assets_texture_states[v[1]]);
				if v[1] == 5 then
					guard_death_state(5, k);
				end
			end
			
			if k == "Iceblood_Tower" then
				Iceblood_Tower_Placeholder:SetTexture(Assets_texture_states[v[1]]);
				if v[1] == 5 then
					guard_death_state(6, k);
				end
			end
			
			if k == "East_Frostwolf_Tower" then
				East_Tower_Placeholder:SetTexture(Assets_texture_states[v[1]]);
				if v[1] == 5 then
					guard_death_state(7, k);
				end
			end
			
			if k == "West_Frostwolf_Tower" then
				West_Tower_Placeholder:SetTexture(Assets_texture_states[v[1]]);
				if v[1] == 5 then
					guard_death_state(8, k);
				end
			end
			
			if k == "Van" then
				Van_update(v[1]);
			end
			
			if k == "Drek" then
				Drek_update(v[1]);
			end
			
			if k == "Stormpike_Aid_Station" then				
				Stormpike_Aid_Station_Placeholder:SetTexture(gy_texture_states[v[1]]);
			end
			
			if k == "Frostwolf_Relief_Hut" then
				Frostwolf_Relief_Hut_Placeholder:SetTexture(gy_texture_states[v[1]]);
			end
			
			if v[1] == 5 then -- update how many guards left
				update_guard_count();
			end
		end
	end
	Drek_combat_update(drek_state);
	Van_combat_update(van_state);
	broadcast_message(Get_my_BG_data(), "all");
end

function SetHealerMana(value)
	if value == 0 then value = 1 end
	if value > 100 then value = 100 end
	if value >= 0 and value <= 100 then
		Mana1:SetWidth((95/100)*value);
		Mana1:SetPoint("LEFT", ((GetScreenWidth() * UIParent:GetEffectiveScale()) / 100 * 50) - (95+9), 320);
	end
end

function SetDPSMana(value)
	if value == 0 then value = 1 end
	if value > 100 then value = 100 end
	if value >= 0 and value <= 100 then
		Mana2:SetPoint("LEFT", ((GetScreenWidth() * UIParent:GetEffectiveScale()) / 100 * 50) + 9, 320);
		Mana2:SetWidth((95/100)*value);
	end
end

local TimerFrame_Brocast = CreateFrame("FRAME");
-- frame creation code here
elapsed_time = 60 -- run the update code 8 times per second
TimerFrame_Brocast:SetScript("OnUpdate", function(elapsed)
	elapsed_time = elapsed_time - arg1
	if elapsed_time > 0 then return end
	elapsed_time = 60
	-- rest of the code here

	if IsInBattleground() and IsinAVBattleground() then
		--broadcast_message(Get_my_BG_data(), "all");
		--console("Sending message");
	end
end)

local TimerFrame = CreateFrame("FRAME");
-- frame creation code here
elapsed_time = 3 -- run the update code 8 times per second
TimerFrame:SetScript("OnUpdate", function(elapsed)
	elapsed_time = elapsed_time - arg1
	if elapsed_time > 0 then return end
	elapsed_time = 3
	-- rest of the code here
	

	if IsinAVBattleground() then
		BGICONS:Show();
		Mana_Images:Show();
		Mana_buttons:Show();
		Boss_buttons:Show();
		all_precent, Healer_precent, DPS_precent = Mana_precentage()
		SetHealerMana(Healer_precent)
		SetDPSMana(DPS_precent)
		
		if drek_pull_time > 0 and GetTime() > drek_pull_time then
			BG_ASSETS["Drek"][1] = 1;
			drek_state = 0;
		end
		
		if van_pull_time > 0 and GetTime() > van_pull_time then
			BG_ASSETS["Van"][1] = 1;
			van_state = 0;
		end

		--update_ui()
	end
end)

function get_boss_health(state)
	if state == 0 then
		return 100;
	elseif state == 2 then
		return 80;
	elseif state == 3 then
		return 60;
	elseif state == 4 then
		return 40;
	elseif state == 5 then
		return 20;
	elseif state == 6 then
		return 5;
	end
end

function Drek_health()
	name, realm = UnitName("target")
	if name == "Drek'Thar" then -- check if we have a target
		say("%t " .. string.format("%.0f", ((UnitHealth("target") / UnitHealthMax("target")) * 100)) .. "%", 2);
	else
		say("Drek'Thar " .. get_boss_health(drek_state) .. "%", 2);
	end
end

function Vans_health()
	name, realm = UnitName("target")
	if name == "Vanndar Stormpike" then -- check if we have a target
		say("%t " .. string.format("%.0f", ((UnitHealth("target") / UnitHealthMax("target")) * 100)) .. "%", 2);
	else
		say("Vanndar Stormpike " .. get_boss_health(van_state) .. "%", 2);
	end
end

function BG_Mana()
	all_precent, Healer_precent, DPS_precent = Mana_precentage()	
	say("Mana: Healers " .. Healer_precent .. "% - DPS " .. DPS_precent .. "%", 2);
end

function GuardsCount()	
	amount = 0
	if get_player_faction() == "Horde" then
		for k, v in pairs(Marshals) do 
			if v[2] == 1 then
				amount = amount + 1;
			end
		end
	else
		for k, v in pairs(Warmasters) do 
			if v[2] == 1 then
				amount = amount + 1;
			end
		end	
	end
		
	if get_player_faction() == "Horde" then
		guards:SetText("Marshs Left: " .. amount);
		say("Marshs Left " .. amount, 2);
	else
		guards:SetText("Warmasters Left: " .. amount);
		say("Warmasters Left " .. amount, 2);
	end
end
	
function reset_data()
	for k, v in pairs(BG_ASSETS) do 
		if k == "West_Frostwolf_Tower" then
			BG_ASSETS[k] = {2}
		elseif k == "East_Frostwolf_Tower" then
			BG_ASSETS[k] = {2}
		elseif k == "Tower_Point" then
			BG_ASSETS[k] = {2}
		elseif k == "Iceblood_Tower" then
			BG_ASSETS[k] = {2}
		elseif k == "Frostwolf_Relief_Hut" then
			BG_ASSETS[k] = {2}
		else
			BG_ASSETS[k] = {1}
		end
	end
	
	for k, v in pairs(Marshals) do 
		if k <= 4 then
			v[2] = 1;
		else
			v[2] = 0;
		end
	end
	
	for k, v in pairs(Warmasters) do 
		if k >= 5 then
			v[2] = 1;
		else
			v[2] = 0;
		end
	end
	
	
	drek_state = 0;
	drek_pull_time = 0; 
	drek_pull_check_time = 0;
	drek_pull_time_compare = 0;

	van_state = 0;
	van_pull_time = 0;
	van_pull_check_time = 0;
	van_pull_time_compare = 0;
	
	update_ui();
	update_guard_count();
end

function update_guard_count()
	amount = 0
	if get_player_faction() == "Horde" then
		for k, v in pairs(Marshals) do 
			if v[2] == 1 then
				amount = amount + 1;
			end
		end
	else
		for k, v in pairs(Warmasters) do 
			if v[2] == 1 then
				amount = amount + 1;
			end
		end	
	end
	
	if get_player_faction() == "Horde" then
		guards:SetText("Marshs Left: " .. amount);
	else
		guards:SetText("Warmasters Left: " .. amount);
	end
	PlaySound("igPVPUpdate");
end

local frame_Boss_Guard_Deaths = CreateFrame("FRAME");
frame_Boss_Guard_Deaths:RegisterEvent("CHAT_MSG_COMBAT_HOSTILE_DEATH");
function eventHandler_Boss_Guard_Deaths(event, ...)
	found = false
	if IsinAVBattleground() then
		if strfind(arg1, "dies") then
			NPC = string.gsub (arg1, " dies.", "", n)
			if get_player_faction() == "Horde" then	
				for k, v in pairs(Marshals) do 
					if NPC == v[1] then
						v[2] = 0;
						found = true
						console(BG_console_name .. " Guard " .. v[1] .. " Died.", "white", getglobal("BG_console_show"))
					end
				end
			else
				for k, v in pairs(Warmasters) do 
					if NPC == v[1] then
						v[2] = 0;
						found = true
						console(BG_console_name .. " Guard " .. v[1] .. " Died.", "white", getglobal("BG_console_show"))
					end
				end
			end
		end
	end
	
	if found then
		update_guard_count();
	end
end
frame_Boss_Guard_Deaths:SetScript("OnEvent", eventHandler_Boss_Guard_Deaths);

-- post game end time at end of BG
local frame1 = CreateFrame("FRAME");
frame1:RegisterEvent("UPDATE_BATTLEFIELD_STATUS");
local function eventHandler(self, event, ...)
	if GetBattlefieldWinner() ~= nil and bg_time ~= GetBattlefieldInstanceRunTime() then
		reset_data()
		bg_time = GetBattlefieldInstanceRunTime();
		if say("Time " .. string.format("%.2f",((bg_time / 1000) / 60)) .. "m", 3, nil, true) then --bypass antispam / also making this into check method fixed issues of not posting results.. idk why, framerate to quick?
			LeaveBattlefield();
		end
	end
end
frame1:SetScript("OnEvent", eventHandler);

if getglobal("BG_console_show") == "true" then
	SLASH_HIDER_SLASHCMD1 = '/bgshow'
	SlashCmdList['HIDER_SLASHCMD'] = function(msg)
		BGICONS:Show();
		Mana_Images:Show();
		Mana_buttons:Show();
		Boss_buttons:Show();
	end

	SLASH_HIDER34_SLASHCMD1 = '/manatest'
	SlashCmdList['HIDER34_SLASHCMD'] = function(msg)
		--SetDPSMana(tonumber(msg))
		--SetHealerMana(tonumber(msg))
		--console("RawData: " .. Get_my_BG_data());
		
		--encoded = Base64_Encode(Get_my_BG_data());
		--console("Data: " .. encoded, "white");
		--console("Data Lenght: " .. string.len(encoded), "white");

		--BG_ASSETS["Icewing_Bunker"][1] = 3;
		--broadcast_message(Get_my_BG_data(), "all");
		--update_ui();
		broadcast_message("request", "update");
	end
end