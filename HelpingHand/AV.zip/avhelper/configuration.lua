--[[  Battleground script  ]]--
setglobal("BG_console_show", "false"); -- enable/disable debug console and commands
BG_console_name = "[AVHelper BG_UI]:"; -- console name

--[[  Synchronize script  ]]--
prefix_Channel = "AVHelper";
prefix_Channel_password = "pass123";
prefix_talking_code = "R2"; -- change when pushing updated version. R = revision then followed by version number

Sync_enable = false; -- master enable/disable switch
Sync_bypass_mode = false; -- set to bypass AV
Sync_hide_channel = false; -- hide channel from chat
setglobal("Sync_console_show", "false"); -- enable/disable debug console and commands
Sync_console_name = "[AVHelper_Sync]:"; -- console name