dps_data = {}

local frame_dps_1 = CreateFrame("FRAME");
frame_dps_1:RegisterEvent("CHAT_MSG_SPELL_SELF_DAMAGE");
frame_dps_1:RegisterEvent("CHAT_MSG_COMBAT_SELF_HITS");
frame_dps_1:RegisterEvent("CHAT_MSG_SPELL_PARTY_DAMAGE");
frame_dps_1:RegisterEvent("CHAT_MSG_COMBAT_PARTY_HITS");
frame_dps_1:RegisterEvent("CHAT_MSG_COMBAT_PET_HITS");
frame_dps_1:RegisterEvent("CHAT_MSG_SPELL_PET_DAMAGE");

function eventHandler_DPS_1(event, ...)
	
	if (strfind( arg1, "fall")) then
		return
	end
	
   s, f, msg = string.find(arg1, "(%d+)");

   if (msg == nil) then
	  return;
   end

   --console("Damage: " .. tonumber(msg), "green")
   table.insert(dps_data, {tonumber(msg), GetTime()})

end
frame_dps_1:SetScript("OnEvent", eventHandler_DPS_1);

local frame_zone_change = CreateFrame("FRAME");
frame_zone_change:RegisterEvent("ZONE_CHANGED_NEW_AREA");
function eventHandler_Zone(event, ...)
	if IsinAVBattleground() then
		reset_data();
		BGICONS:Show();
		Mana_Images:Show();
		Mana_buttons:Show();
		Boss_buttons:Show();
		frame_dps_1:RegisterEvent("CHAT_MSG_COMBAT_FRIENDLYPLAYER_HITS");
		frame_dps_1:RegisterEvent("CHAT_MSG_SPELL_FRIENDLYPLAYER_DAMAGE");
		sync_connect();
		broadcast_message("request", "update");
	else
		BGICONS:Hide();
		Mana_Images:Hide();
		Mana_buttons:Hide();
		Boss_buttons:Hide();
		reset_data();
		frame_dps_1:UnregisterEvent("CHAT_MSG_COMBAT_FRIENDLYPLAYER_HITS");
		frame_dps_1:UnregisterEvent("CHAT_MSG_SPELL_FRIENDLYPLAYER_DAMAGE");
		sync_disconnect();
	end
end
frame_zone_change:SetScript("OnEvent", eventHandler_Zone);

SLASH_DPS_SLASHCMD1 = '/dps'
SlashCmdList['DPS_SLASHCMD'] = function(msg)
	tryDPS()
end

function tryDPS()
	number = calculate_dps();
	if number then
		if UnitHealth("target") > 0 then
			say("%t " .. string.format("%.0f", ((UnitHealth("target") / UnitHealthMax("target")) * 100)) .. "% (Death in " .. number .. "s)", 2);
		else
			say("DPS " .. number, 1);
		end
	else
	console("More time needed to gather DPS rating.", "blue")
	end
end

function calculate_dps()
	local target_hp = UnitHealth("target")
	if tablelength(dps_data) > 0 then
		start_time = dps_data[1][2];
		end_time = dps_data[tablelength(dps_data)][2];
		howlong = end_time - start_time

		dmg_done = 0
		last_time = start_time
		deduct_time = 0
		
		if howlong > 10 then
			for k, v in pairs(dps_data) do
				if ((v[2] - last_time) > 2) then
					deduct_time = deduct_time + ((v[2] - last_time))
				end
				dmg_done = dmg_done + v[1]
				last_time = v[2]
			end
			
			dps = (dmg_done / (howlong - deduct_time))
			
			if target_hp > 0 then
				return string.format("%.2f", (target_hp / dps))
			else
				return string.format("%.0f", dps)
			end
		else
			return false
		end
	end
end


SLASH_DPSReset_SLASHCMD1 = '/resetdps'
SlashCmdList['DPSReset_SLASHCMD'] = function(msg)
	dps_data = {}
	console("DPS is resetted", "blue");
end

local frameDPS = CreateFrame("FRAME");
frameDPS:RegisterEvent("PLAYER_TARGET_CHANGED");
local function eventHandlerDPS(self, event, ...)
	if UnitHealth("target") > 0 and UnitIsEnemy("player","target") then
		NPC_button:Show();
	else
		NPC_button:Hide();
	end
end
frameDPS:SetScript("OnEvent", eventHandlerDPS);
