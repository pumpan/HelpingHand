duel_reset_mode = false

SLASH_DRESET_SLASHCMD1 = '/duel_reset'
SlashCmdList['DRESET_SLASHCMD'] = function(msg)
	if duel_reset_mode == false then
		if UnitExists("target") then
			name, realm = UnitName("target")
			whisper("Reset", name);
			StartDuel(name);
			say(".duel on", 1);
			duel_reset_mode = true;
		else
			console("You have no target", "blue");
		end
	else
		duel_reset_mode = false;
		console("Canceled Duel", "blue");
		CancelDuel();
	end
end

local frameDReset = CreateFrame("FRAME");
frameDReset:RegisterEvent("CHAT_MSG_SYSTEM");
local function eventHandlerDuelSYSTEM(self, event, ...)
	if duel_reset_mode then
		if string.find(arg1, "3") then
			CancelDuel();
			duel_reset_mode = false;
		end
	end
end
frameDReset:SetScript("OnEvent", eventHandlerDuelSYSTEM);