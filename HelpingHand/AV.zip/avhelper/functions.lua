anti_spam_time = 0;
itemnames = {};

function convert_percentage(current_val, max_val) -- convert into percentage
	result = (current_val / max_val) * 100;
	if result > 0 then
		return tonumber(string.format("%.0f", result));
	else
		return 0; -- if under 0, send default
	end
end

function get_chat_type(level) -- whatever is first it will use Exmple: 0 = say (restricted), 1 = say/party, 2 = say/party/raid, 3 = say/party/raid/raid warning
	if(UnitInRaid("player")) then
		if (IsRaidLeader() and level >= 3) then
			return "RAID_WARNING";
		else
			if (level >= 2) then
				if GetBattlefieldInstanceRunTime() > 0 then
					return "BATTLEGROUND";
				else
					return "RAID";
				end
			end
		end
	end
	if GetNumPartyMembers() ~= 0 and level >= 1 then
		return "PARTY";
	else
		return "SAY";
	end
end

function anti_spam(delay) -- no longer panic spam, note delay arg must always be passed
	if anti_spam_time > GetTime() then -- check time
		return false;
	else
		anti_spam_time = GetTime() + (delay); -- set seconds
		return true;
	end
end

function IsInBattleground()
	inInstance, instanceType = IsInInstance()
	if inInstance and instanceType == "pvp" then
		return true
	else
		return false
	end
end

function IsinAVBattleground()
	local x = GetNumBattlefieldStats();
	if x == 7 then
		return true
	else
		return false
	end
end

function say(text, level, delay, bypass_antispam) -- easy way to use SendChatMessage
	level = level or 3; --arg defaults
	delay = delay or 2; --arg defaults
	bypass_antispam = bypass_antispam or false; -- default should be false
	
	if bypass_antispam == false then -- check if we should bypass
		if anti_spam(delay) then -- active antispam
			SendChatMessage(text, get_chat_type(level), nil, nil);
		end
	else
		SendChatMessage(text, get_chat_type(level), nil, nil);
	end
	return true;
end

function whisper(text, name) -- easy way to use SendChatMessage
	if anti_spam(anti_spam_time, 10) then -- active antispam
		SendChatMessage(text, "WHISPER", "common", name);
	end
	return true;
end

function toboolean(text)
	text = tostring(text);
	if text == "true" then
		return true;
	elseif text == "false" then
		return false;
	else
		return;
	end
end

function console(text, color_name, display) 
	display = display or true;
	color_name = color_name or "red"; --arg defaults
	display = toboolean(display)
	
	if display == true then
		function color(name)
			function rbg_to_float(r, b, g)
				return (r / 255), (b / 255), (g / 255);
			end

			if name == "green" then
				return rbg_to_float(124,252,0);
			elseif name == "blue" then
				return rbg_to_float(135,206,250);
			elseif name == "yellow" then
				return rbg_to_float(255,255,0);
			elseif name == "white" then
				return rbg_to_float(255,255,255);
			elseif name == "orange" then
				return rbg_to_float(255,127,80);
			elseif name == "red" then
				return rbg_to_float(255,0,0);
			else
				return rbg_to_float(255,0,0); -- default red. if color doesnt exists then default to red
			end
		end
		
		r, b, g = color(color_name);
		
		DEFAULT_CHAT_FRAME:AddMessage(text, r, b, g);
	end
end

function ChatColor(color_name)
	r, b, g = color(color_name);
	ChangeChatColor("SAY", r, b, g);
end

function random_text(array)
	return array[math.random(tablelength(array))]
end

function get_player_faction()
	englishFaction, localizedFaction = UnitFactionGroup("player");
	return englishFaction;
end

function Get_Battleground_Instance_ID()
	for i=1, 5, 1 do
		status, mapName, instanceID, lowestlevel, highestlevel, teamSize, registeredMatch = GetBattlefieldStatus(i)
		if status == "active" then
			return tostring(instanceID);
		end
	end
	return false;
end

function Item_ScanInspect(unit)
	itemnames = {};

	local i, j, slotName,sunit,ifScanSet;
	local itemName, tmpText, tmpStr, tmpSet, val, lines, set;

	sunit="target";
	ifScanSet=0;

	for i=1, 19 ,1 do
		
		local link = nil;
		link = GetInventoryItemLink(sunit, i);

		if (link~=nil) then

			local item = gsub(link, ".*(item:%d+:%d+:%d+:%d+).*", "%1", 1);
			
			SCObjectTooltip:Hide()
			SCObjectTooltip:SetOwner(UIParent, "ANCHOR_NONE");

			SCObjectTooltip:SetHyperlink(item);			
			itemName = SCObjectTooltipTextLeft1:GetText();
			lines = SCObjectTooltip:NumLines();

			for j=2, lines, 1 do
				tmpText = getglobal("SCObjectTooltipTextLeft"..j);
				val = nil;
				if (tmpText:GetText()) then
					tmpStr = tmpText:GetText();
				end
			end
			table.insert(itemnames, itemName)
		end
	end
	
	SCObjectTooltip:Hide()
end

function Mana_precentage()
	--set up vars
	all_max_mana = 0;
	all_current_mana = 0;
	all_precent = nil;
	
	DPS_max_mana = 0;
	DPS_current_mana = 0;
	DPS_precent = nil;
	
	Healer_max_mana = 0;
	Healer_current_mana = 0;
	Healer_precent = nil;
	
	-- the math
	if(UnitInRaid("player")) then -- if in raid
		members = GetNumRaidMembers(); -- get all raid members
		for i = members,0,-1 do
			name, rank, subgroup, level, class, fileName, zone, online, isDead, role, isML = GetRaidRosterInfo(i);
			unit_id = "raid"..i;
			if (class ~= "Rouge" and class ~= "Warrior") then
				if (class == "Priest" or class == "Shaman" or class == "Paladin" or class == "Druid") then
					Healer_max_mana = UnitManaMax(unit_id) + Healer_max_mana;
					Healer_current_mana = UnitMana(unit_id) + Healer_current_mana;
				end
				if (class == "Mage" or class == "Warlock" or class == "Hunter") then
					DPS_max_mana = UnitManaMax(unit_id) + DPS_max_mana;
					DPS_current_mana = UnitMana(unit_id) + DPS_current_mana;
				end
			end
		end
	
	elseif (GetNumPartyMembers() ~= 0) then -- have to use GetNumPartyMembers() as the other method is broken, if in party
		members = GetNumPartyMembers();
		for i = members,1,-1 do
			unit_id = "party"..GetPartyMember(i); -- get all party members
			class, englishClass = UnitClass(unit_id);		
			if (class ~= "Rouge" and class ~= "Warrior") then
				if (class == "Priest" or class == "Shaman" or class == "Paladin" or class == "Druid") then
					Healer_max_mana = UnitManaMax(unit_id) + Healer_max_mana;
					Healer_current_mana = UnitMana(unit_id) + Healer_current_mana;
				end
				if (class == "Mage" or class == "Warlock" or class == "Hunter") then
					DPS_max_mana = UnitManaMax(unit_id) + DPS_max_mana;
					DPS_current_mana = UnitMana(unit_id) + DPS_current_mana;
				end
			end
		end		
	end
	
	all_max_mana = DPS_max_mana + Healer_max_mana;
	all_current_mana = DPS_current_mana + Healer_current_mana;
	
	--convert percentages
	DPS_precent = convert_percentage(DPS_current_mana, DPS_max_mana)
	Healer_precent = convert_percentage(Healer_current_mana, Healer_max_mana)
	all_precent = convert_percentage(all_current_mana, all_max_mana)
	
	return all_precent, Healer_precent, DPS_precent
end

function strsplit(str, delimiter)
	local count = string.find(str, delimiter)
	local Datatable = { }
	for i = 1, 500 do
		count = string.find(str, delimiter)
		if count == nil then
			console("Stopped")
			break
		end
		result = string.sub( str, 1 , count-1 )
		console(result, "say")
		table.insert(Datatable, result)
		str = string.gsub(str, string.format("%s,", result), "", 1)
	end
	return Datatable
end

-- table helper functions
function tablelength(T)
  local count = 0
  for _ in pairs(T) do count = count + 1 end
  return count
end

function dump(o)
   if type(o) == 'table' then
      local s = '{ '
      for k,v in pairs(o) do
         if type(k) ~= 'number' then k = '"'..k..'"' end
         s = s .. '['..k..'] = ' .. dump(v) .. ','
      end
      return s .. '} '
   else
      return tostring(o)
   end
end