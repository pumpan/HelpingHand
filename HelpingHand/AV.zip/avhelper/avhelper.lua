--golbal vars
bg_time = nil;
duel_mode = 0;

-- simple commands for AV, its the little things that count too
SLASH_KILL_SLASHCMD1 = '/kill'
SlashCmdList['KILL_SLASHCMD'] = function(msg)
	if UnitName("target") then -- check if we have a target
		say("Kill %t", 3);
	end
end

SLASH_rlui_SLASHCMD1 = '/reload'
SlashCmdList['rlui_SLASHCMD'] = function(msg)
	if msg == "ui" then
		ReloadUI();
	end
end

SLASH_ALLIN_SLASHCMD1 = '/allin'
SlashCmdList['ALLIN_SLASHCMD'] = function(msg)
	say("All in", 3);
end

SLASH_HEALTH_SLASHCMD1 = '/health'
SlashCmdList['HEALTH_SLASHCMD'] = function(msg)
	if UnitExists("targettarget") and UnitIsEnemy("targettarget", "player") then
		last_name = UnitName("target")
		AssistUnit("target")
		say("%t " .. string.format("%.0f", ((UnitHealth("target") / UnitHealthMax("target")) * 100)) .. "%", 2);
		TargetByName(last_name, true);
	elseif UnitName("target") then -- check if we have a target
		say("%t " .. string.format("%.0f", ((UnitHealth("target") / UnitHealthMax("target")) * 100)) .. "%", 2);
	end
end


SLASH_HEALTHH_SLASHCMD1 = '/health2'
SlashCmdList['HEALTHH_SLASHCMD'] = function(msg)

	if UnitExists("targettarget") then
		last_name = UnitName("target")
		AssistUnit("target")
		say("%t " .. string.format("%.0f", ((UnitHealth("target") / UnitHealthMax("target")) * 100)) .. "%", 2);
		TargetByName(last_name, true);
	end
end

SLASH_DUEL_SLASHCMD1 = '/duelcon'
SlashCmdList['DUEL_SLASHCMD'] = function(msg) --simple switch
	if(duel_mode == 0) then
		console("No longer accepting Duels", "red");
		duel_mode = 1;
	else
		console("Accepting Duels", "green");
		duel_mode = 0;
	end
end

SLASH_SCORE_SLASHCMD1 = '/score'
SlashCmdList['SCORE_SLASHCMD'] = function(msg)
	Gear_score = 0;
	if CheckInteractDistance("target", 1) then
		Item_ScanInspect("target");
		for k,v in itemnames do
			if Item_score_data[v] ~= nil then
				Gear_score = Item_score_data[v] + Gear_score;
			end
		end
	end
	if Gear_score > 0 then
		say("%t's gear score " .. Gear_score, 2); 
	end
end

SLASH_TEST_SLASHCMD1 = '/test'
SlashCmdList['TEST_SLASHCMD'] = function(msg)
	console("Time: " .. GetBattlefieldInstanceRunTime());

end

-- this is for naxx, /kicked <spellname>
SLASH_KICK_SLASHCMD1 = '/kicked'
SlashCmdList['KICK_SLASHCMD'] = function(msg) -- must pass spell name here
	if UnitName("target") and (UnitIsEnemy("player","target")) then -- check if we have a target
		local i = 1; -- spell id index
		while true do
			spellName, spellRank = GetSpellName(i, BOOKTYPE_SPELL);
			
			if(spellName == msg) then -- found spell name! continue with everything
				break;
			end
			if not spellName then -- no spell found, cancel whole thing
				return false; 
			end
			i = i + 1;
		end
   
		start, duration, enabled = GetSpellCooldown(i, "spell");
		if(start == 0) then -- check if we can cast right now
			CastSpell(i, "spell"); --spell index id, this might be diffrent for ea class -- 47
			start, duration, enabled = GetSpellCooldown(i, "spell"); -- check if was cast, TODO: Bug - this can fail us and delay us..
			if start > 0 then --if cast then announce
				say("Kicked %t", 0, 5); -- 5 sec delay
				return true;
			end
		end
		console("Kick Failed");
		--say("Kick Failed", 0, 1); --if all checks fail lets announced we failed
	end
end

SLASH_MANA2_SLASHCMD1 = '/mana'
SlashCmdList['MANA2_SLASHCMD'] = function(msg)
	all_precent, Healer_precent, DPS_precent = Mana_precentage()	
	say("Mana: Total " .. all_precent .. "% - Healers " .. Healer_precent .. "% - DPS " .. DPS_precent .. "%", 2);
end

-- duel system
local frame2 = CreateFrame("FRAME");
frame2:RegisterEvent("DUEL_REQUESTED");
local function eventHandler2(self, event, ...)
	if(duel_mode == 1) then
		CancelDuel();
		whisper(random_text({"No duels", "nty", "busy"}), arg1);
	end
end
frame2:SetScript("OnEvent", eventHandler2);


-- Auto bind_pickup
local frameBOP = CreateFrame("FRAME");
frameBOP:RegisterEvent("LOOT_BIND_CONFIRM");
frameBOP:RegisterEvent("CONFIRM_LOOT_ROLL");
local function eventHandlerBOP(self, event, ...)
	--console("Called3");
	--if arg1 then
		--console("Called2");
		--RollOnLoot(arg1, nil)
	--else
		--console("Called");
		ConfirmBindOnUse();
	--end
end
frameBOP:SetScript("OnEvent", eventHandlerBOP);


-- duel system
--local frame5 = CreateFrame("FRAME");
--frame5:RegisterEvent("PLAYER_CONTROL_LOST");
local function eventHandler5(self, event, ...)
	--if IsInBattleground() == true and IsinAVBattleground() == true and GetBattlefieldWinner() == nil then

	
	local TimerFrame2 = CreateFrame("FRAME");
	elapsed_time2 = 1
	TimerFrame2:SetScript("OnUpdate", function(elapsed)
		elapsed_time2 = elapsed_time2 - arg1
		if elapsed_time2 > 0 then return end
	
		-- rest of the code here
		
		for i=1,40 do 
			local D = UnitDebuff("player",i); 
			if D then 
				console(i.."="..D) 
			end 
		end
	
	end)
	
		--say("Loss Control", 3, nil, true)
	--end
end
--frame5:SetScript("OnEvent", eventHandler5);



